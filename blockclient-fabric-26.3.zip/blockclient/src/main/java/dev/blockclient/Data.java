package dev.blockclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.function.Supplier;

/** Every Minecraft data read for the HUD lives here. If an MC update renames something, fix it here. */
public final class Data {
    private static final long SESSION_START = System.currentTimeMillis();
    private static Minecraft mc() { return Minecraft.getInstance(); }

    // ---------------- per-frame / per-tick stats ----------------
    private static int fps, frames;
    private static long fpsT = System.nanoTime();
    private static final ArrayDeque<Long> leftClicks = new ArrayDeque<>(), rightClicks = new ArrayDeque<>();
    private static boolean lastL, lastR;
    private static double speed, px, pz;
    private static boolean hasPos;

    public static void frame() {
        frames++;
        long n = System.nanoTime();
        if (n - fpsT >= 1_000_000_000L) { fps = frames; frames = 0; fpsT = n; }
        boolean l = mc().mouseHandler.isLeftPressed(), r = mc().mouseHandler.isRightPressed();
        long ms = System.currentTimeMillis();
        if (mc().gui.screen() == null) {
            if (l && !lastL) leftClicks.add(ms);
            if (r && !lastR) rightClicks.add(ms);
        }
        lastL = l; lastR = r;
        while (!leftClicks.isEmpty() && ms - leftClicks.peek() > 1000) leftClicks.poll();
        while (!rightClicks.isEmpty() && ms - rightClicks.peek() > 1000) rightClicks.poll();
    }

    public static void tick() {
        Player p = mc().player;
        if (p == null) { hasPos = false; return; }
        if (hasPos) speed = Math.hypot(p.getX() - px, p.getZ() - pz) * 20.0;
        px = p.getX(); pz = p.getZ(); hasPos = true;
    }

    public static int leftCps() { return leftClicks.size(); }
    public static int rightCps() { return rightClicks.size(); }

    public static String safe(Supplier<String> s) {
        try { String v = s.get(); return v == null ? "-" : v; } catch (Throwable t) { return "?"; }
    }

    // ---------------- text values ----------------
    public static String fps() { return fps + " FPS"; }

    public static String ping() {
        var c = mc().getConnection();
        if (c == null || mc().player == null) return "Ping: -";
        var info = c.getPlayerInfo(mc().player.getUUID());
        return info == null ? "Ping: -" : "Ping: " + info.getLatency() + " ms";
    }

    public static String coords() {
        Player p = mc().player;
        return String.format("XYZ: %.1f / %.1f / %.1f", p.getX(), p.getY(), p.getZ());
    }

    public static String nether() {
        Player p = mc().player;
        boolean inNether = dimension().equalsIgnoreCase("the nether");
        double f = inNether ? 8.0 : 1.0 / 8.0;
        return String.format("%s: %.1f / %.1f", inNether ? "Overworld" : "Nether", p.getX() * f, p.getZ() * f);
    }

    public static String chunk() {
        BlockPos b = mc().player.blockPosition();
        return "Chunk: " + (b.getX() >> 4) + ", " + (b.getZ() >> 4) + "  (in: " + (b.getX() & 15) + ", " + (b.getZ() & 15) + ")";
    }

    public static String facing() {
        float yaw = Mth.wrapDegrees(mc().player.getYRot());
        double a = (yaw + 180.0) % 360.0;
        String[] d = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};
        return "Facing: " + d[((int) ((a + 22.5) / 45.0)) % 8] + " (" + Math.round(yaw) + "°)";
    }

    public static String rotation() {
        Player p = mc().player;
        return String.format("Yaw %.1f  Pitch %.1f", Mth.wrapDegrees(p.getYRot()), p.getXRot());
    }

    public static String biome() {
        var h = mc().level.getBiome(mc().player.blockPosition());
        return "Biome: " + pretty(h.getRegisteredName());
    }

    public static String dimension() {
        // ResourceKey#toString looks like "ResourceKey[minecraft:dimension / minecraft:overworld]"
        String s = mc().level.dimension().toString();
        int i = s.lastIndexOf("/ ");
        if (i >= 0) s = s.substring(i + 2);
        return pretty(s.replace("]", ""));
    }

    public static String speed() { return String.format("Speed: %.2f b/s", speed); }
    public static String cps() { return "CPS: " + leftCps() + " | " + rightCps(); }

    public static String day() {
        return "Day " + (mc().level.getDefaultClockTime() / 24000L + 1);
    }

    public static String worldTime() {
        long t = mc().level.getDefaultClockTime() % 24000L;
        long hours = (t / 1000 + 6) % 24, mins = (t % 1000) * 60 / 1000;
        return String.format("World time: %02d:%02d", hours, mins);
    }

    public static String realTime() { return LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")); }
    public static String date() { return LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")); }

    public static String session() {
        long s = (System.currentTimeMillis() - SESSION_START) / 1000;
        return String.format("Session: %d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
    }

    public static String moon() {
        String[] n = {"Full Moon", "Waning Gibbous", "Last Quarter", "Waning Crescent",
                "New Moon", "Waxing Crescent", "First Quarter", "Waxing Gibbous"};
        return "Moon: " + n[(int) ((mc().level.getDefaultClockTime() / 24000L) % 8)];
    }

    public static String weather() {
        var l = mc().level;
        return "Weather: " + (l.isThundering() ? "Thunderstorm" : l.isRaining() ? "Rain" : "Clear");
    }

    public static String light() {
        return "Light: " + mc().level.getMaxLocalRawBrightness(mc().player.blockPosition());
    }

    public static String health() {
        Player p = mc().player;
        String s = String.format("HP: %.1f / %.0f", p.getHealth(), p.getMaxHealth());
        if (p.getAbsorptionAmount() > 0) s += String.format("  (+%.0f)", p.getAbsorptionAmount());
        return s;
    }

    public static String hunger() {
        var f = mc().player.getFoodData();
        return String.format("Food: %d  Sat: %.1f", f.getFoodLevel(), f.getSaturationLevel());
    }

    public static String xp() {
        Player p = mc().player;
        return "XP: Lvl " + p.experienceLevel + " (" + Math.round(p.experienceProgress * 100) + "%)";
    }

    public static String sprint() { return mc().player.isSprinting() ? "Sprinting" : "Walking"; }

    public static String targetBlock() {
        HitResult h = mc().hitResult;
        if (h instanceof BlockHitResult b && h.getType() == HitResult.Type.BLOCK)
            return "Looking at: " + mc().level.getBlockState(b.getBlockPos()).getBlock().getName().getString();
        return "Looking at: -";
    }

    public static String targetEntity() {
        HitResult h = mc().hitResult;
        if (h instanceof EntityHitResult e && h.getType() == HitResult.Type.ENTITY) {
            Entity t = e.getEntity();
            String s = "Target: " + t.getName().getString();
            if (t instanceof LivingEntity le) s += String.format("  %.1f / %.0f HP", le.getHealth(), le.getMaxHealth());
            return s;
        }
        return "Target: -";
    }

    public static String entities() {
        int n = 0;
        for (Entity ignored : mc().level.entitiesForRendering()) n++;
        return "Entities: " + n;
    }

    public static String memory() {
        Runtime r = Runtime.getRuntime();
        long used = (r.totalMemory() - r.freeMemory()) >> 20, max = r.maxMemory() >> 20;
        return "Mem: " + used + " / " + max + " MB (" + (used * 100 / Math.max(1, max)) + "%)";
    }

    public static String server() {
        ServerData sd = mc().getCurrentServer();
        return "Server: " + (sd == null ? "Singleplayer" : sd.ip);
    }

    public static String players() {
        var c = mc().getConnection();
        return "Players: " + (c == null ? 0 : c.getOnlinePlayers().size());
    }

    public static String heldItem() {
        ItemStack s = mc().player.getMainHandItem();
        if (s.isEmpty()) return "Held: -";
        String r = "Held: " + s.getHoverName().getString();
        if (s.getCount() > 1) r += " x" + s.getCount();
        if (s.getMaxDamage() > 0) r += "  (" + (s.getMaxDamage() - s.getDamageValue()) + "/" + s.getMaxDamage() + ")";
        return r;
    }

    public static String arrows() {
        Inventory inv = mc().player.getInventory();
        int n = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.is(Items.ARROW)) n += s.getCount();
        }
        return "Arrows: " + n;
    }

    // ---------------- helpers ----------------
    private static String pretty(String id) {
        int i = id.indexOf(':');
        if (i >= 0) id = id.substring(i + 1);
        String[] parts = id.replace('_', ' ').split(" ");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
        }
        return sb.toString();
    }
}
