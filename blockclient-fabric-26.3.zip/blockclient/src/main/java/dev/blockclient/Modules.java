package dev.blockclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public final class Modules {
    public static final List<HudModule> ALL = new ArrayList<>();
    private static int slot = 0;
    public static HudModule freelook, swing;

    public static void init() {
        // ---- on by default ----
        txt("fps", "FPS Counter", true, Data::fps);
        txt("ping", "Ping", true, Data::ping);
        txt("coords", "Coordinates", true, Data::coords);
        txt("cps", "CPS Counter", true, Data::cps);
        txt("day", "Day Counter", true, Data::day);
        add("keystrokes", "Keystrokes", true, 4, 9999, Modules::drawKeystrokes);
        add("armor", "Armor HUD", true, 9999, 90, Modules::drawArmor);
        add("potions", "Potion Effects", true, 9999, 4, Modules::drawPotions);

        // ---- off by default ----
        add("inventory", "Inventory HUD", false, 9999, 9999, Modules::drawInventory);
        txt("nether", "Nether Coordinates", false, Data::nether);
        txt("chunk", "Chunk Coordinates", false, Data::chunk);
        txt("facing", "Direction", false, Data::facing);
        txt("rotation", "Yaw / Pitch", false, Data::rotation);
        txt("biome", "Biome", false, Data::biome);
        txt("dimension", "Dimension", false, () -> "Dimension: " + Data.dimension());
        txt("speed", "Speed", false, Data::speed);
        txt("worldTime", "World Time", false, Data::worldTime);
        txt("realTime", "Clock", false, Data::realTime);
        txt("date", "Date", false, Data::date);
        txt("session", "Session Time", false, Data::session);
        txt("moon", "Moon Phase", false, Data::moon);
        txt("weather", "Weather", false, Data::weather);
        txt("light", "Light Level", false, Data::light);
        txt("health", "Health", false, Data::health);
        txt("hunger", "Hunger", false, Data::hunger);
        txt("xp", "XP Level", false, Data::xp);
        txt("sprint", "Sprint Status", false, Data::sprint);
        txt("targetBlock", "Target Block", false, Data::targetBlock);
        txt("targetEntity", "Target Entity", false, Data::targetEntity);
        txt("entities", "Entity Count", false, Data::entities);
        txt("memory", "Memory Usage", false, Data::memory);
        txt("server", "Server Address", false, Data::server);
        txt("players", "Players Online", false, Data::players);
        txt("heldItem", "Held Item", false, Data::heldItem);
        txt("arrows", "Arrow Counter", false, Data::arrows);
        txt("watermark", "Watermark", false, () -> "BlockClient");

        // ---- feature-only modules (no HUD) ----
        freelook = add("freelook", "Freelook (hold key)", false, 0, 0, null);
        swing = add("swing", "Swing Speed", false, 0, 0, null);
        HudModule ts = add("toggleSprint", "Toggle Sprint", false, 0, 0, null);
        ts.tick = () -> {
            Minecraft mc = Minecraft.getInstance();
            Player p = mc.player;
            if (p == null || mc.gui.screen() != null) return;
            if (mc.options.keyUp.isDown() && !p.isUsingItem() && !p.horizontalCollision
                    && p.getFoodData().getFoodLevel() > 6) p.setSprinting(true);
        };
    }

    public static void tick() {
        for (HudModule m : ALL) if (m.st.enabled && m.tick != null) {
            try { m.tick.run(); } catch (Throwable t) { ClientMod.LOG.warn("Tick {} failed: {}", m.id, t.toString()); }
        }
    }

    public static void renderAll(GuiGraphicsExtractor g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        for (HudModule m : ALL) if (m.st.enabled) m.render(g);
    }

    // ---------------------------------------------------------------- registration helpers
    private static HudModule add(String id, String name, boolean en, int x, int y, HudModule.Draw d) {
        ModState s = Config.INSTANCE.mods.get(id);
        if (s == null) { s = new ModState(en, x, y); Config.INSTANCE.mods.put(id, s); }
        HudModule m = new HudModule(id, name, d, s);
        ALL.add(m);
        return m;
    }

    private static void txt(String id, String name, boolean en, Supplier<String> sup) {
        int i = slot++;
        add(id, name, en, 4 + (i / 20) * 120, 4 + (i % 20) * 12, textDraw(sup));
    }

    private static HudModule.Draw textDraw(Supplier<String> sup) {
        return (g, m, x, y) -> {
            String[] lines = Data.safe(sup).split("\n");
            int lh = Gfx.lineHeight(), w = 0;
            for (String l : lines) w = Math.max(w, Gfx.width(l));
            m.w = w + 4;
            m.h = lines.length * (lh + 1) + 3;
            if (m.st.bg) Gfx.fill(g, x, y, x + m.w, y + m.h, 0x90000000);
            for (int i = 0; i < lines.length; i++)
                Gfx.text(g, lines[i], x + 2, y + 2 + i * (lh + 1), m.st.color, m.st.shadow);
        };
    }

    // ---------------------------------------------------------------- special modules
    private static void drawKeystrokes(GuiGraphicsExtractor g, HudModule m, int x, int y) {
        var o = Minecraft.getInstance().options;
        var mh = Minecraft.getInstance().mouseHandler;
        m.w = 60; m.h = 74;
        key(g, m, "W", o.keyUp.isDown(), x + 20, y, 18, 18);
        key(g, m, "A", o.keyLeft.isDown(), x, y + 20, 18, 18);
        key(g, m, "S", o.keyDown.isDown(), x + 20, y + 20, 18, 18);
        key(g, m, "D", o.keyRight.isDown(), x + 40, y + 20, 18, 18);
        key(g, m, "LMB " + Data.leftCps(), mh.isLeftPressed(), x, y + 40, 29, 18);
        key(g, m, "RMB " + Data.rightCps(), mh.isRightPressed(), x + 31, y + 40, 29, 18);
        key(g, m, "-----", o.keyJump.isDown(), x, y + 60, 60, 12);
    }

    private static void key(GuiGraphicsExtractor g, HudModule m, String label, boolean down, int x, int y, int w, int h) {
        Gfx.fill(g, x, y, x + w, y + h, down ? 0xB0FFFFFF : 0x90000000);
        int tc = down ? 0xFF000000 : m.st.color;
        int ty = y + (h - Gfx.lineHeight()) / 2 + 1;
        Gfx.text(g, label, x + (w - Gfx.width(label)) / 2, ty, tc, false);
    }

    private static void drawArmor(GuiGraphicsExtractor g, HudModule m, int x, int y) {
        Player p = Minecraft.getInstance().player;
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        int maxW = 18;
        for (int i = 0; i < 4; i++) {
            ItemStack s = p.getItemBySlot(slots[i]);
            int ry = y + i * 18;
            if (s.isEmpty()) continue;
            Gfx.item(g, s, x, ry);
            if (s.getMaxDamage() > 0) {
                int left = s.getMaxDamage() - s.getDamageValue();
                double f = left / (double) s.getMaxDamage();
                int col = 0xFF000000 | ((int) (255 * (1 - f)) << 16) | ((int) (255 * f) << 8) | 0x20;
                String t = String.valueOf(left);
                Gfx.text(g, t, x + 19, ry + 4, col, m.st.shadow);
                maxW = Math.max(maxW, 19 + Gfx.width(t));
            }
        }
        m.w = maxW; m.h = 72;
    }

    private static void drawInventory(GuiGraphicsExtractor g, HudModule m, int x, int y) {
        Inventory inv = Minecraft.getInstance().player.getInventory();
        m.w = 9 * 18 + 4; m.h = 3 * 18 + 4;
        Gfx.fill(g, x, y, x + m.w, y + m.h, 0x90000000);
        for (int i = 0; i < 27; i++) {
            ItemStack s = inv.getItem(9 + i);
            int sx = x + 2 + (i % 9) * 18 + 1, sy = y + 2 + (i / 9) * 18 + 1;
            Gfx.item(g, s, sx, sy);
            Gfx.itemDecor(g, s, sx, sy);
        }
    }

    private static void drawPotions(GuiGraphicsExtractor g, HudModule m, int x, int y) {
        Player p = Minecraft.getInstance().player;
        int row = 0, maxW = 40, lh = Gfx.lineHeight() + 2;
        for (MobEffectInstance e : p.getActiveEffects()) {
            String name = e.getEffect().value().getDisplayName().getString();
            int amp = e.getAmplifier();
            if (amp > 0) name += " " + roman(amp + 1);
            String time = e.isInfiniteDuration() ? "∞"
                    : String.format("%d:%02d", e.getDuration() / 1200, (e.getDuration() / 20) % 60);
            boolean low = !e.isInfiniteDuration() && e.getDuration() < 200;
            String line = name + "  " + time;
            if (m.st.bg) Gfx.fill(g, x, y + row * lh, x + Gfx.width(line) + 4, y + row * lh + lh, 0x90000000);
            Gfx.text(g, line, x + 2, y + row * lh + 1, low ? 0xFFFF5555 : m.st.color, m.st.shadow);
            maxW = Math.max(maxW, Gfx.width(line) + 4);
            row++;
        }
        m.w = maxW; m.h = Math.max(1, row) * lh;
    }
    private static int maxW;   // scratch for drawPotions

    private static String roman(int n) {
        String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return n < r.length ? r[n] : String.valueOf(n);
    }
}
