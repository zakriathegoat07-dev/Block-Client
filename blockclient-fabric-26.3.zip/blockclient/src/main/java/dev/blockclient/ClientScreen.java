package dev.blockclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class ClientScreen extends Screen {
    private static final int PER_PAGE = 8;
    private static final int[] PRESETS = {0xFFFFFFFF, 0xFFFFE066, 0xFF55FF55, 0xFF55FFFF, 0xFFFF77CC, 0xFFFF5555, 0xFFFFAA00, 0xFFB388FF};
    private static final String[] NAMES = {"White", "Yellow", "Green", "Cyan", "Pink", "Red", "Orange", "Purple"};

    private int page = 0;
    private HudModule selected;
    private boolean layout = false;
    private HudModule dragging;
    private int dragDX, dragDY;
    private boolean prevLeft;

    public ClientScreen() { super(Component.literal("BlockClient")); }

    public boolean isLayoutMode() { return layout; }
    @Override public boolean isPauseScreen() { return false; }

    @Override
    protected void init() {
        int cx = width / 2;
        if (layout) {
            btn("Done", cx - 40, height - 28, 80, () -> { layout = false; rebuildWidgets(); });
            return;
        }
        List<HudModule> all = Modules.ALL;
        int pages = (all.size() + PER_PAGE - 1) / PER_PAGE;
        page = Math.max(0, Math.min(page, pages - 1));
        int lx = cx - 190, rx = cx + 10;

        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= all.size()) break;
            HudModule m = all.get(idx);
            btn((m.st.enabled ? "§a[ON]  §r" : "§c[OFF] §r") + m.name, lx, 30 + i * 22, 150,
                    () -> { m.st.enabled = !m.st.enabled; selected = m; rebuildWidgets(); });
            btn(m == selected ? "▶" : "⚙", lx + 152, 30 + i * 22, 22, () -> { selected = m; rebuildWidgets(); });
        }
        int ny = 30 + PER_PAGE * 22 + 2;
        btn("◀", lx, ny, 40, () -> { page = (page + pages - 1) % pages; rebuildWidgets(); });
        btn("▶", lx + 134, ny, 40, () -> { page = (page + 1) % pages; rebuildWidgets(); });

        if (selected != null && selected.draw != null) {
            ModState s = selected.st;
            btn("Color: " + colorName(s.color), rx, 52, 176, () -> { s.color = nextColor(s.color); rebuildWidgets(); });
            EditBox hex = new EditBox(font, rx, 76, 176, 20, Component.literal("Hex"));
            hex.setHint(Component.literal("Custom color #RRGGBB"));
            hex.setMaxLength(7);
            hex.setResponder(t -> { Integer v = parseHex(t); if (v != null) s.color = v; });
            addRenderableWidget(hex);
            btn("Shadow: " + (s.shadow ? "ON" : "OFF"), rx, 100, 86, () -> { s.shadow = !s.shadow; rebuildWidgets(); });
            btn("Bg: " + (s.bg ? "ON" : "OFF"), rx + 90, 100, 86, () -> { s.bg = !s.bg; rebuildWidgets(); });
            btn("Scale -", rx, 124, 86, () -> s.scale = Math.max(0.5f, Math.round((s.scale - 0.1f) * 10) / 10f));
            btn("Scale +", rx + 90, 124, 86, () -> s.scale = Math.min(3.0f, Math.round((s.scale + 0.1f) * 10) / 10f));
            btn("X -", rx, 148, 42, () -> s.x = Math.max(0, s.x - 5));
            btn("X +", rx + 44, 148, 42, () -> s.x += 5);
            btn("Y -", rx + 90, 148, 42, () -> s.y = Math.max(0, s.y - 5));
            btn("Y +", rx + 134, 148, 42, () -> s.y += 5);
            btn("Edit HUD Layout (drag)", rx, 172, 176, () -> { layout = true; rebuildWidgets(); });
        } else if (selected != null) {
            ModState s = selected.st;
            switch (selected.id) {
                case "swing" -> {
                    btn("Faster", rx, 52, 86, () -> s.speed = Math.max(0.3f, Math.round((s.speed - 0.1f) * 10) / 10f));
                    btn("Slower", rx + 90, 52, 86, () -> s.speed = Math.min(3.0f, Math.round((s.speed + 0.1f) * 10) / 10f));
                }
                default -> { }
            }
        }
        btn("Done", rx, ny, 176, this::onClose);
    }

    private Button btn(String label, int x, int y, int w, Runnable r) {
        Button b = Button.builder(Component.literal(label), btn -> r.run()).bounds(x, y, w, 20).build();
        addRenderableWidget(b);
        return b;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractRenderState(g, mouseX, mouseY, partialTick);
        int cx = width / 2;

        boolean left = Minecraft.getInstance().mouseHandler.isLeftPressed();
        if (layout) {
            Modules.renderAll(g);
            for (HudModule m : Modules.ALL) {
                if (!m.st.enabled || m.draw == null) continue;
                Gfx.outline(g, m.st.x - 1, m.st.y - 1, m.st.x + m.w + 1, m.st.y + m.h + 1,
                        m == dragging ? 0xFF55FF55 : 0xAAFFFFFF);
            }
            String hint = "Drag modules to move them  -  click Done when finished";
            Gfx.text(g, hint, cx - Gfx.width(hint) / 2, 10, 0xFFFFFFFF, true);

            boolean onDone = mouseX >= cx - 40 && mouseX <= cx + 40 && mouseY >= height - 28 && mouseY <= height - 8;
            if (left && !prevLeft && !onDone) {
                for (int i = Modules.ALL.size() - 1; i >= 0; i--) {
                    HudModule m = Modules.ALL.get(i);
                    if (m.st.enabled && m.draw != null && mouseX >= m.st.x && mouseX <= m.st.x + m.w
                            && mouseY >= m.st.y && mouseY <= m.st.y + m.h) {
                        dragging = m; dragDX = mouseX - m.st.x; dragDY = mouseY - m.st.y; break;
                    }
                }
            }
            if (left && dragging != null) {
                dragging.st.x = Math.max(0, Math.min(mouseX - dragDX, width - dragging.w));
                dragging.st.y = Math.max(0, Math.min(mouseY - dragDY, height - dragging.h));
            }
            if (!left) dragging = null;
        } else {
            Gfx.text(g, "BlockClient  -  " + Modules.ALL.size() + " modules", cx - 190, 12, 0xFF55FFFF, true);
            int enabled = (int) Modules.ALL.stream().filter(m -> m.st.enabled).count();
            String info = enabled + " enabled   -   page " + (page + 1) + "/" + ((Modules.ALL.size() + PER_PAGE - 1) / PER_PAGE);
            Gfx.text(g, info, cx + 10, 12, 0xFFAAAAAA, false);
            if (selected != null) {
                String t = "Settings: " + selected.name + (selected.draw != null ? String.format("  (%.1fx)", selected.st.scale) : "");
                Gfx.text(g, t, cx + 10, 38, 0xFFFFFFFF, true);
                ModState st = selected.st;
                switch (selected.id) {
                    case "freelook" -> {
                        Gfx.text(g, "Hold the Freelook key (default V,", cx + 10, 56, 0xFFAAAAAA, false);
                        Gfx.text(g, "change it in Controls) and move the mouse", cx + 10, 68, 0xFFAAAAAA, false);
                        Gfx.text(g, "to look around without turning.", cx + 10, 80, 0xFFAAAAAA, false);
                    }
                    case "swing" -> Gfx.text(g, String.format("Swing duration: x%.1f  (higher = slower)", st.speed), cx + 10, 78, 0xFFAAAAAA, false);
                    default -> { }
                }
            }
            else
                Gfx.text(g, "Click ⚙ on a module for its settings", cx + 10, 38, 0xFFAAAAAA, false);
        }
        prevLeft = left;
    }

    @Override
    public void removed() { Config.INSTANCE.save(); }

    private static int nextColor(int cur) {
        for (int i = 0; i < PRESETS.length; i++) if (PRESETS[i] == cur) return PRESETS[(i + 1) % PRESETS.length];
        return PRESETS[0];
    }
    private static String colorName(int c) {
        for (int i = 0; i < PRESETS.length; i++) if (PRESETS[i] == c) return NAMES[i];
        return String.format("#%06X", c & 0xFFFFFF);
    }
    private static Integer parseHex(String s) {
        s = s.startsWith("#") ? s.substring(1) : s;
        if (s.length() != 6) return null;
        try { return 0xFF000000 | Integer.parseInt(s, 16); } catch (NumberFormatException e) { return null; }
    }
}
