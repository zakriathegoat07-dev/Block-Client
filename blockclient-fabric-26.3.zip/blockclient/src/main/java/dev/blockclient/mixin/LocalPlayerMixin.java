package dev.blockclient.mixin;

import dev.blockclient.Freelook;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Freelook backup hook: covers the case where LocalPlayer declares its own turn(). Skipped if it doesn't. */
@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin {
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true, require = 0)
    private void blockclient$turn(double yRot, double xRot, CallbackInfo ci) {
        if (Freelook.onTurn((Entity) (Object) this, yRot, xRot)) ci.cancel();
    }
}
