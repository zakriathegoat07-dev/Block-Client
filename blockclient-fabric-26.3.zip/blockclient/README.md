# BlockClient (Fabric, Minecraft 26.3)
39 HUD/feature modules in one mod. Press K in game to open the menu.

Build: JDK 25 + Gradle 9.8+
    gradle wrapper --gradle-version 9.8.2
    ./gradlew build
Put build/libs/blockclient-0.1.0.jar and Fabric API 26.3 in your mods folder.

## Extra modules (use Mixins)
- Freelook: hold V (rebindable in Controls) to look around without turning.
- Swing Speed: slower/faster arm swing animation (visual only).
Mixins are non-fatal: if one doesn't match Minecraft 26.3 it is skipped and logged, and the rest of the mod still works.
