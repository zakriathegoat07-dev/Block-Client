package dev.blockclient;

public class ModState {
    public boolean enabled;
    public int x, y;
    public int color = 0xFFFFFFFF;
    public boolean shadow = true;
    public boolean bg = false;
    public float scale = 1.0f;                 // HUD scale (HUD modules) / item scale (Held Item Tweaks)
    public float ox = 0f, oy = 0f, oz = 0f;    // Held Item Tweaks offsets
    public float speed = 1.5f;                 // Swing Speed duration multiplier (higher = slower)

    public ModState() {}
    public ModState(boolean enabled, int x, int y) { this.enabled = enabled; this.x = x; this.y = y; }
}
