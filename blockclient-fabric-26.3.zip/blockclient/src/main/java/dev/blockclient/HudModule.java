package dev.blockclient;

import net.minecraft.client.gui.GuiGraphicsExtractor;

public final class HudModule {
    /** Draws at (x,y) and must set m.w / m.h to its (unscaled) size. */
    public interface Draw { void draw(GuiGraphicsExtractor g, HudModule m, int x, int y); }

    public final String id, name;
    public final Draw draw;          // null for feature-only modules (Toggle Sprint, Freelook, ...)
    public Runnable tick;            // optional per-tick logic
    public final ModState st;
    public int w, h;                 // last drawn size, AFTER scaling

    public HudModule(String id, String name, Draw draw, ModState st) {
        this.id = id; this.name = name; this.draw = draw; this.st = st;
    }

    public void render(GuiGraphicsExtractor g) {
        if (draw == null) return;
        if (w > 0) {                       // keep on screen (also resolves the 9999 default anchors)
            st.x = Math.max(0, Math.min(st.x, Gfx.screenW() - w));
            st.y = Math.max(0, Math.min(st.y, Gfx.screenH() - h));
        }
        float sc = Math.max(0.3f, Math.min(4f, st.scale));
        try {
            if (Math.abs(sc - 1f) < 0.001f) {
                draw.draw(g, this, st.x, st.y);
            } else {
                Gfx.pushScale(g, st.x, st.y, sc);
                try { draw.draw(g, this, 0, 0); } finally { Gfx.popScale(g); }
                w = Math.round(w * sc);
                h = Math.round(h * sc);
            }
        } catch (Throwable t) { ClientMod.LOG.warn("Module {} failed: {}", id, t.toString()); }
    }
}
