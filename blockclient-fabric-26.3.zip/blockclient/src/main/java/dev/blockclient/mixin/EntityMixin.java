package dev.blockclient.mixin;

import dev.blockclient.Freelook;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Freelook: while active, mouse movement rotates the camera instead of the player. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true, require = 0)
    private void blockclient$turn(double yRot, double xRot, CallbackInfo ci) {
        if (Freelook.onTurn((Entity) (Object) this, yRot, xRot)) ci.cancel();
    }
}
