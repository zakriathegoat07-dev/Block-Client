package dev.blockclient;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientMod implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("blockclient");

    @Override
    public void onInitializeClient() {
        Modules.init();
        Config.INSTANCE.save();

        KeyMapping menu = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.blockclient.menu", InputConstants.KEY_K, KeyMapping.Category.MISC));

        KeyMapping freelookKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.blockclient.freelook", InputConstants.KEY_V, KeyMapping.Category.MISC));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            Freelook.update(mc, freelookKey.isDown());
            Data.tick();
            Modules.tick();
            while (menu.consumeClick()) mc.setScreenAndShow(new ClientScreen());
        });

        HudElementRegistry.attachElementAfter(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("blockclient", "hud"),
                (graphics, tickCounter) -> {
                    Data.frame();
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.options.hideGui) return;
                    if (mc.gui.screen() instanceof ClientScreen cs && cs.isLayoutMode()) return; // screen draws them itself
                    Modules.renderAll(graphics);
                });
    }
}
