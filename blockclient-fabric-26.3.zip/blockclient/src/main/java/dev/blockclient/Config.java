package dev.blockclient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

public final class Config {
    public Map<String, ModState> mods = new LinkedHashMap<>();

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static Config INSTANCE = load();

    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("blockclient.json"); }

    private static Config load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Config c = GSON.fromJson(Files.readString(p), Config.class);
                if (c != null && c.mods != null) return c;
            }
        } catch (Exception e) { ClientMod.LOG.warn("Could not read config", e); }
        return new Config();
    }

    public void save() {
        try { Files.writeString(path(), GSON.toJson(this)); }
        catch (Exception e) { ClientMod.LOG.warn("Could not save config", e); }
    }
}
