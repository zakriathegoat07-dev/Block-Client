package dev.blockclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.ItemStack;

/** Thin wrapper over Minecraft GUI drawing. If an MC update renames something, fix it here. */
public final class Gfx {
    public static int width(String s) { return Minecraft.getInstance().font.width(s); }
    public static int lineHeight() { return Minecraft.getInstance().font.lineHeight; }
    public static int screenW() { return Minecraft.getInstance().getWindow().getGuiScaledWidth(); }
    public static int screenH() { return Minecraft.getInstance().getWindow().getGuiScaledHeight(); }

    public static void text(GuiGraphicsExtractor g, String s, int x, int y, int argb, boolean shadow) {
        g.text(Minecraft.getInstance().font, s, x, y, argb, shadow);
    }
    public static void fill(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int argb) {
        g.fill(x1, y1, x2, y2, argb);
    }
    public static void outline(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int argb) {
        fill(g, x1, y1, x2, y1 + 1, argb); fill(g, x1, y2 - 1, x2, y2, argb);
        fill(g, x1, y1, x1 + 1, y2, argb); fill(g, x2 - 1, y1, x2, y2, argb);
    }
    public static void item(GuiGraphicsExtractor g, ItemStack stack, int x, int y) {
        if (stack.isEmpty()) return;
        g.item(stack, x, y);
    }
    public static void itemDecor(GuiGraphicsExtractor g, ItemStack stack, int x, int y) {
        if (stack.isEmpty()) return;
        g.itemDecorations(Minecraft.getInstance().font, stack, x, y);
    }

    /** Start drawing scaled at (x,y): everything drawn at (0,0) afterwards appears at (x,y) scaled. */
    public static void pushScale(GuiGraphicsExtractor g, int x, int y, float scale) {
        g.pose().pushMatrix();
        g.pose().translate((float) x, (float) y);
        g.pose().scale(scale, scale);
    }
    public static void popScale(GuiGraphicsExtractor g) { g.pose().popMatrix(); }
}
