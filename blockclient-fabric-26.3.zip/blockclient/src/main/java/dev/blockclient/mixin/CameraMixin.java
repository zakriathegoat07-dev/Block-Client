package dev.blockclient.mixin;

import dev.blockclient.Freelook;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Freelook: override the camera rotation while the freelook key is held. */
@Mixin(Camera.class)
public abstract class CameraMixin {
    @ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private float blockclient$yaw(float yaw) { return Freelook.active() ? Freelook.yaw : yaw; }

    @ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 1, require = 0)
    private float blockclient$pitch(float pitch) { return Freelook.active() ? Freelook.pitch : pitch; }
}
