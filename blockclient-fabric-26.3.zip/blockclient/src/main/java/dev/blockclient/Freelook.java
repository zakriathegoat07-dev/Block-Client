package dev.blockclient;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;

public final class Freelook {
    private static boolean active;
    public static float yaw, pitch;

    public static boolean active() { return active; }

    public static void update(Minecraft mc, boolean keyDown) {
        boolean want = keyDown && Modules.freelook != null && Modules.freelook.st.enabled
                && mc.player != null && mc.gui.screen() == null;
        if (want && !active) { yaw = mc.player.getYRot(); pitch = mc.player.getXRot(); }
        active = want;
    }

    /** Called from the Entity#turn mixin. Returns true if the mouse movement was consumed. */
    public static boolean onTurn(Entity e, double dYaw, double dPitch) {
        if (!active || e != Minecraft.getInstance().player) return false;
        yaw += (float) (dYaw * 0.15);
        pitch = Math.max(-90f, Math.min(90f, pitch + (float) (dPitch * 0.15)));
        return true;
    }
}
