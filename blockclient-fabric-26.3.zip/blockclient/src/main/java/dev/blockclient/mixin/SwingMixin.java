package dev.blockclient.mixin;

import dev.blockclient.HudModule;
import dev.blockclient.Modules;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Swing Speed: scale how long YOUR arm swing animation takes (visual only). */
@Mixin(LivingEntity.class)
public abstract class SwingMixin {
    @Inject(method = "getCurrentSwingDuration", at = @At("RETURN"), cancellable = true, require = 0)
    private void blockclient$swing(CallbackInfoReturnable<Integer> cir) {
        HudModule m = Modules.swing;
        if (m == null || !m.st.enabled) return;
        if ((Object) this != Minecraft.getInstance().player) return;
        cir.setReturnValue(Math.max(1, Math.round(cir.getReturnValue() * m.st.speed)));
    }
}
